package com.niit.clicartbckend.dao;

import java.io.Serializable;
import java.util.List;

import com.niit.clicartbckend.model.BillingAddress;

public interface BillingAddressDao extends Serializable{
	public boolean savebilladdrs(BillingAddress address);
	public boolean Updatebilladdrs(BillingAddress address);
	public boolean deletebilladdrs(BillingAddress address);
	public BillingAddress get(String id);
	public List<BillingAddress> listofAddresses();
public String getmaxbillingaddressid();
}
