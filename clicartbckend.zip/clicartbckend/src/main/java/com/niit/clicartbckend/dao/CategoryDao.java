package com.niit.clicartbckend.dao;

import java.util.List;

import com.niit.clicartbckend.model.Category;
public interface CategoryDao {

	public String save(Category category);
	public String update(Category category);
	public boolean delete(Category category);
	public Category get(String id);
	public List<Category> list();
}
