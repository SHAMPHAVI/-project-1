package com.niit.clicartbckend.dao;

import java.util.List;

import com.niit.clicartbckend.model.Supplier;

public interface SupplierDao {

	public String save(Supplier supplier);
	public String update(Supplier supplier);
	public boolean delete(Supplier supplier);
	public Supplier get(String id);
	public List<Supplier> list();
}
